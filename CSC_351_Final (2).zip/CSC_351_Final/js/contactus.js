
function checkFields(){
	
	var user = document.forms["contact"]["name"].value;
	var email = document.forms["contact"]["email"].value;
	var id = document.forms["contact"]["id"].value;
	var message = document.forms["contact"]["message"].value;
	
	
	if(user == null || user == ""){
		alert("Error, missing student's name");
	} else if (id == null || id == ""){
		alert("Error, missing student's ID");
	} else if(email == null || email == ""){
		alert("Error, missing student's email address");
	} else if(message == "Enter Message Here..."){
		alert("Please enter a message");
	} else {
		onSubmit();
	}

}	
	
	
	



function onSubmit(){
	alert("Your response has been recorded, thank you!");
}
