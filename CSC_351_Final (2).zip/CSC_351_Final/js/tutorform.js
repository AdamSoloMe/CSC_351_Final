
function checkFields(){
	
	var name = document.forms["tutor"]["name"].value;
	var id = document.forms["tutor"]["id"].value;
	var course = document.forms["tutor"]["course"].value;
	var TimeSlot = document.forms["tutor"]["TimeSlot"].value;
	var tutor = document.forms["tutor"]["tutors"].value;
	
	if (name == null || name == ""){
		alert("Error, missing student's name");
	} else if (id == null || id == ""){
		alert("Error, missing student's ID");
	} else if (course == "na"){
		alert("Error, missing course");
	} else if (TimeSlot == "na"){
		alert("Error, missing time slot");
	} else if (tutor == "na"){
		alert("Error, missing tutor");
	} else {
		onSubmit();
	}
	
	
}

function onSubmit(){
	alert("Submission Received, Please check your email for a confirmation");
}

